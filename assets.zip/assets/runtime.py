import pygame,threading
import pickle,datetime
import random,math
import sys,json,time
sys.path.append('assets//')
import numpy  as np
pygame.init()
from assets.behaviors import behavior
from assets.object_handling import *
from assets import particle

data = '.dat'
Asset = '.asset'
Script = '.script'
behaviorex = '.behavior'
wex = '.w'
obj='.obj'
class Error:
    def __init__(self):
        self.id = 0
        self.error=''
    
class Errors:
    newerror=0
    history = []
    def register(error):
        e = Error()
        
        Errors.newerror += 1
        e.id = Errors.newerror
        e.error = f'ERROR Number {e.id} an error occured at {datetime.datetime.now()} : ' +  error 
        Errors.history.append(e)
def save(obj,path):
    pickle.dump(obj,open(path + data,'wb'))
def load(path):
    return pickle.load(open(path + data,'rb'))
def Destroy(obj):
    del(obj)
class components:
    class movement:
        def __init__(self,vel=1):
            self.vel=vel
            self.parent=None
        def run(self,args):
           # print(10)
            k = pygame.key.get_pressed()
            if k[pygame.K_s]:
                self.parent.pos.y += self.vel
            if k[pygame.K_w]:
                self.parent.pos.y -= self.vel
            if k[pygame.K_d]:
                self.parent.pos.x += self.vel
            if k[pygame.K_a]:
                self.parent.pos.x -= self.vel
    class rigidbody:
        def __init__(self,tag='global'):
            self.tag=tag
            self.parent=None
        def run(self,args):
            pass
        
class internal:
    class vars:
        pass
def RunScript(file):
    x=0
    try:
        if file.endswith(Script):
            for line in open(file):
                x += 1
                #print(line)
                exec(line)
    except Exception as e:
        Errors.register(f'line {x} in file "{file}" > {str(e)}')
class Cam:
    def __init__(self,name="new cam",pos=[0,0,0],src=''):
        self.pos = pos
        self.name=name#[0,0,0]
        self.lockedObj=False
        self.behavior=behavior(src)
        self.col=(200,255,255)
    def update(**args):
        self.behavior.run()
        pass

class workspace:
    Objects = np.array([],dtype=object)#[]
    MainCamera = Cam("main cam")
    name='Untitled workspace'
    
    def delete(obj):
        del(obj)
    def load(self,new):
        self = pickle.load(open(new,'rb'))
    def save(path=''):
        pickle.dump(workspace,open(path + workspace.name + wex,'wb'))
    pass
def register(self):
    self.parent=workspace
    workspace.Objects = np.append(workspace.Objects,self)

particle.emitter.register = register
class behavior:
    def __init__(self,path=''):
        self.src = ''
        if path == '':
            pass
        else:
            try:
                self.src=open(path).read()
            except Exception as e:
                print(f'failed to load behavior {path}') 
                self.src=''
    def run(self):
        exec(self.src)
    def load(self,path):
        if path.endswith(behaviorex) == True:
            self.src=open(path).read()
        else:
            print(f"cannot load a .{path.split('.')[-1]} file! please use .behavior!")
class Object:
    def __init__(self,x=0,y=0,w=0,h=0,parent=workspace):
        self.pos = pygame.Rect(x,y,w,h)
        self.render=False
        self.name='New Object'
        self.ii = False
        self.parent = parent
        self.components=[]
        self.Texture=pygame.Surface((w,h));self.Texture.fill((255,0,0))
        self.behavior=behavior()
    def add_component(self,component):
        self.components.append(component)
        self.components[-1].parent=self
    def update(self,**args):
        for component in self.components:
            component.run(args)
        exec(self.behavior.src)
    def Destroy(self):
        self = None
    def set_parent(location):
        self.parent = location
    def save(self,path=''):
        pickle.dump(self,open(path + self.name + obj,'wb'))
    def load(self,path):
        self = pickle.load(open(path,'rb'))
    def register(self):
        """registers an object to be updated by the game"""
        if self not in workspace.Objects:
            #workspace.Objects.append(self)
            #print(f'registered {self}')
            workspace.Objects = np.append(workspace.Objects,self)
            #print(workspace.Objects)


class game:
    w,h=0,0
    fps=0
    version='0.0.1'
    atributes = []
    window = None
    currentCam=workspace.MainCamera
    workspace=workspace
    dt = 1
    clock = pygame.time.Clock()
    def init(self,w=500,h=500,fps=60,attributes=[]):
        self.w = w
        self.h=h
        self.fps=fps
        self.atributes=attributes
        self.window = pygame.display.set_mode((self.w,self.h))
    def update(source='',rects=[]):
        if len(rects) >= 1:
             if source == '':
                
                pygame.display.update(rects)
             else:
                RunScript(source)
                pygame.display.update(rects)
        else:
            if source == '':
                
                pygame.display.update()
            else:
                RunScript(source)
                pygame.display.update()
    def start(script='main.script',argv=sys.argv):
        RunScript(script)
        config=None
        #objmanager = threading.Thread(target=Object_Manager)
        #objmanager.start()
##        for i in dir(workspace):
##                try:
##                        if type(eval(f'workspace.{i}')) == Object:
##                            workspace.Objects.append(eval(f'workspace.{i}'))
##                            #eval(f'workspace.{i}').update(window=game.window,fps=game.fps,dt=game.dt,events=events)
##                except Exception as e:
##                    print(e)
        try:
            config=json.load('config.json')
            game.init(config['w'],config['h'],config['fps'],config['attributes'])
        except Exception:
            game.init(game)
        lt = time.time()
        dt = 0
        for errors in Errors.history:print(errors.error)
        while True:
            game.clock.tick(game.fps)
            events = pygame.event.get()
            for event in events:
                if event == pygame.QUIT:
                    pygame.quit()
                    exit()
            dt = time.time() - lt
            dt *= game.fps
            #print(workspace.Objects)
            game.window.fill(game.currentCam.col)
            for object in game.workspace.Objects:
                
                object.update(window=game.window,fps=game.fps,dt=game.dt,events=events)
            
            if config == None:
                game.update()
               # print(1)
            else:
                game.update(config['rendersrc'])
game.start()
