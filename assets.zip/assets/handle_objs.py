surface=None
def update(object,render=True,surface,**arg):
    
        
    object.update(surface,arg)
    
    pass
