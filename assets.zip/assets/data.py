import numpy as np
class array:
    def __init__(self,data,dt=None,name=None):
        self.data=np.array(data,dtype=dt)
        self.name=name
    def append(self,data):
        self.data= np.append(self.data,data)
    def delete(self,data):
        self.data=np.delete(self.data,data)
