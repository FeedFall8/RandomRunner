import random
import numpy
import datetime
class behavior:
    def __init__(self,path=''):
        self.src = ''
        if path == '':
            pass
        else:
            try:
                self.src=open(path).read()
            except Exception as e:
                print(f'failed to load behavior {path}') 
                self.src=''
    def run(self):
        exec(self.src)
    def load(self,path):
        if path.endswith(behaviorex) == True:
            self.src=open(path).read()
        else:
            print(f"cannot load a .{path.split('.')[-1]} file! please use .behavior!")
