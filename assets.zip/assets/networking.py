import socket,datetime
from _thread import *
def hostname():
    return socket.gethostname()
def gethostbyname(name):
    return socket.gethostbyname(name)
class Client:
    def __init__(self,ip,port):
        self.ip=ip
        self.port=port
        self.socket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        self.freply = self.socket.connect((ip,port))
    def send(self,data):
        self.socket.sendall(data)
    pass
class Connection:
    def __init__(self,connection,addr):
        self.conn=connection
        self.addr=addr
        
    
class Server:
    def __init__(self,ip=socket.gethostbyname(socket.gethostname()),port=19132,maxconnections=2):
        self.ip=ip
        self.port=port
        self.server = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        self.data = {}
        self.recvsize=1024
        
       
        try:
            self.server.bind((ip,port))
        except Exception as e:
            print(f'failed to bind to addresses > {e}')
        self.server.listen(maxconnections)
    def threaded_client(self,client,behavior=None):
        while True:
            data = client.conn.recv(self.recvsize)
            if data:
                print(f"recv {data}")
            else:
                print(f'communication ended with {client}')
                break
    def run(self,log=False,threaded=False,reply=None):
        while True:
            con,addr = self.server.accept()
            if log:
                print(f"connected to server {addr} at {datetime.datetime.now()}")
            connection = Connection(con,addr)
            
            self.threaded_client(connection)
    pass
 

##while True:
##    # wait for a connection
##    print ('waiting for a connection')
##    connection, client_address = sock.accept()
##
##    try:
##        # show who connected to us
##        print ('connection from', client_address)
##
##        # receive the data in small chunks and print it
##        while True:
##            data = connection.recv(64)
##            if data:
##                # output received data
##                print ("Data: %s" % data)
##            else:
##                # no more data -- quit the loop
##                print ("no more data.")
##                break
##    finally:
##        # Clean up the connection
##        connection.close()
