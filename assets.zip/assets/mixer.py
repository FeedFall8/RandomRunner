import pygame
pygame.mixer.init()
class Channels:
    channels = []
    next=1
class Channel:
    def __init__(self):
        self.channel =  pygame.mixer.Channel(Channels.next)
        Channels.channels.append(self)
        Channels.next += 1
def load(fp):
    pygame.mixer_music.load(fp)
def play(pos=-1):
    pygame.mixer_music.play(pos)
def get_pos():
    return pygame.mixer_music.get_pos()
class Sound:
    def __init__(self,fp):
        self.sound=pygame.mixer.Sound(fp)
    def load(self,fp):
        self.sound=pygame.mixer.Sound(fp)
